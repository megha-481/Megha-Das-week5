package com.laraib;

public @interface Test {

}
