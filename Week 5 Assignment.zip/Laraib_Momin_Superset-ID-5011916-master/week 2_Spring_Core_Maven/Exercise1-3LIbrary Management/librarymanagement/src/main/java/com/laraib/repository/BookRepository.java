package com.laraib.repository;


public class BookRepository {
    public BookRepository(){
        System.out.println("BookRepository instance inside IoC Container created !");
    }
}
