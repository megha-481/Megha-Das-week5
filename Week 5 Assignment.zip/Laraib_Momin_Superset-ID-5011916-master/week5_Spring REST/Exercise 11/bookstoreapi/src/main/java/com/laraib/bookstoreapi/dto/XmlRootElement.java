package com.laraib.bookstoreapi.dto;

public @interface XmlRootElement {

}
