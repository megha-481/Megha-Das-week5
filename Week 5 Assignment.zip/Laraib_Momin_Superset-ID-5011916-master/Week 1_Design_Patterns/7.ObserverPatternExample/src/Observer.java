// Observer.java
public interface Observer {
    void update(double stockPrice);
}
